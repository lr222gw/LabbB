//Lowe Raivio - 9403245930
#ifndef TEST_SHAPE_REGISTER_H
#define TEST_SHAPE_REGISTER_H

void test();

#endif // !TEST_SHAPE_REGISTER_H
